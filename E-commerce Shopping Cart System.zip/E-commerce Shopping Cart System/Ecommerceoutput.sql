USE ecommerce_db;
SELECT * FROM Users;
SELECT * FROM Products;
SELECT * FROM DiscountCodes;
SELECT * FROM CartItems;
SELECT * FROM Orders;
SELECT * FROM OrderItems;
SELECT * FROM Payments;